const { instance } = require("../utils/axios");
const { requestResponse } = require("../utils");
const nodemailer = require('nodemailer');

let response;
/**
 * @function sendMail
 * Send a mail
 * @param {String} fullname
 * @returns {Promise<{code: number, message: string, status: boolean}>}
 */
const sendMail = async (profile) => {
  const { FIRST_NAME, LAST_NAME, TYPE } = profile;
  const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
        user: 'dashawn.haley54@ethereal.email',
        pass: 'vq7pKfBj8AbCy5qZmC'
    }
  });
  
  try {
    await transporter.sendMail({
      from: `erin@gmail.com`,
      to: `${FIRST_NAME}@gmail.com`,
      subject: `Hey this is your ${TYPE}`,
      text: `Hello ${FIRST_NAME} ${LAST_NAME}!.`,
    });

    return { ...requestResponse.success };
  } catch (error) {
    throw new Error(error);
  }
};

module.exports = {
  sendMail,
};
