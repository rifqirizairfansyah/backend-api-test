module.exports = {
  globalTeardown: "./globalTeardown.js",
  globals: {
    'process.env.NODE_ENV': 'development'
  },
};
